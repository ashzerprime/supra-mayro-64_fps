Mario‑64 style demo (libre)
==========================
Contenu du ZIP:
- index.html  : page autonome (utilise Three.js via CDN)
- coin.wav    : petit son de collecte

Instructions:
1) Dépose le contenu du ZIP à la racine d'un repo GitHub (ou juste index.html + coin.wav).
2) Active GitHub Pages sur la branche main (root). Le site sera accessible sur:
   https://<ton-nom>.github.io/<repo>/

Ce projet utilise uniquement géométries procédurales et textures générées dynamiquement,
aucun actif protégé n'est inclus. Tu peux remplacer la géométrie 'Mario' par un modèle glTF
si tu veux un rendu plus fidèle.
